package com.example.navigation;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.navigation.fragment.NavHostFragment;

public class homeFragment extends Fragment {

    private EditText editTextFirstName, editTextLastName, editTextGPA;
    private Button button1, button2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        editTextFirstName = view.findViewById(R.id.editTextFirstName);
        editTextLastName = view.findViewById(R.id.editTextLastName);
        editTextGPA = view.findViewById(R.id.editTextGPA);
        button1 = view.findViewById(R.id.button1);
        button2 = view.findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered information
                String firstName = editTextFirstName.getText().toString();
                String lastName = editTextLastName.getText().toString();
                String gpa = editTextGPA.getText().toString();

                // Pass the information to the ProfileFragment
                Bundle bundle = new Bundle();
                bundle.putString("firstName", firstName);
                bundle.putString("lastName", lastName);
                bundle.putString("gpa", gpa);
                NavHostFragment.findNavController(homeFragment.this)
                        .navigate(R.id.action_home2_to_profile, bundle);
            }
        });

        button1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Clear the editText fields
                editTextFirstName.setText("");
                editTextLastName.setText("");
                editTextGPA.setText("");
                return true;
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the ListFragment
                NavHostFragment.findNavController(homeFragment.this)
                        .navigate(R.id.action_home2_to_list2);
            }
        });

        return view;
    }
}
