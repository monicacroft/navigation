package com.example.navigation;

import androidx.fragment.app.Fragment;

public class home2 extends Fragment {
}
